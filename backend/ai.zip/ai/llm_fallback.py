from google import genai
import json
import re
from app.config.settings import settings

class LLMFallback:
    """
    Uses the modern Google GenAI SDK to parse complex natural language queries.
    """
    
    def __init__(self):
        self.enabled = bool(settings.GEMINI_API_KEY)
        if self.enabled:
            # Use the newer google.genai Client
            self.client = genai.Client(api_key=settings.GEMINI_API_KEY)
            self.model_id = "gemini-1.5-flash"
        else:
            self.client = None

    async def parse_query(self, query):
        if not self.enabled:
            return None
            
        prompt = f"""
        Act as a food ordering assistant. Extract search parameters from the following user query:
        "{query}"
        
        Return ONLY a valid JSON object with these exact keys:
        - vegetarian: (boolean or null)
        - spicy: (boolean or null)
        - max_price: (number or null)
        - category: (string or null) Choose from: [Veg Starters, Non-Veg Starters, Veg Main Course, Non-Veg Main Course, Breads, Rice, Desserts, Beverages]
        - keywords: (list of strings) Search terms for food items.
        - excluded_keywords: (list of strings) Things the user explicitly DOES NOT want.
        
        Constraints:
        - If the user says "with a kick" or "hot", set spicy to true.
        - If the user says "easy on wallet" or "cheap", set max_price to 250 unless a specific amount is mentioned.
        - If the user says "healthy", add keywords like "salad", "grilled", "steamed".
        
        Output ONLY JSON:
        """
        
        try:
            # Modern SDK call
            response = self.client.models.generate_content(
                model=self.model_id,
                contents=prompt
            )
            text = response.text
            
            # Extract JSON from response
            json_match = re.search(r'\{.*\}', text, re.DOTALL)
            if json_match:
                return json.loads(json_match.group(0))
            return None
        except Exception as e:
            print(f"LLM Fallback Error: {e}")
            return None

llm_fallback = LLMFallback()
